//
//  HomeTableViewCell.swift
//  Demotest
//
//  Created by 甘禹 on 2018/8/24.
//  Copyright © 2018年 甘禹. All rights reserved.
//

import UIKit

class HomeTableViewCell: UITableViewCell {
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var views: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       views.layer.cornerRadius = 8
    }

    @IBAction func button(_ sender: Any) {
        let viewss = UIView(frame: CGRect(x:120,y:200,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        let label = UILabel(frame:CGRect(x:100,y:50,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        label.text = "回电话回电话的健康快点快点"
        views.addSubview(viewss)
        viewss.addSubview(label)
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
