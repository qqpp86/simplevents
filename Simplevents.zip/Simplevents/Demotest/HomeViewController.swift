//
//  HomeViewController.swift
//  TableViewSpread-swift
//
//  Created by 甘禹 on 2018/8/24.
//  Copyright © 2018年 pxh. All rights reserved.
//

import UIKit
class HomeViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var tableView : UITableView?
    
    var tableData = [["title":"Swift - 让标签栏按钮UITabBarItem图片居中","image":"101.png"],
                     ["title":"Swift - 使用SSZipArchive实现文件的压缩、解压缩","image":"102.png"],
                     ["title":"Swift - 使用LINQ操作数组/集合","image":"103.png"],
                     ["title":"Swift - 给表格UITableView添加索引功能","image":"104.png"],
                     ["title":"Swift - 列表项尾部附件点击响应","image":"105.png"],
                     ["title":"Swift - 自由调整图标按钮中的图标和文字位置","image":"106.png"]]
     var selectedCellIndexPaths:[IndexPath] = []
    override func loadView() {
        super.loadView()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavBar()
       // self.navigationController?.navigationItem = "Simp"
       
        self.tableView = UITableView(frame:CGRect(x:0,y:80,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height), style: .plain)
        self.tableView!.delegate = self
        self.tableView?.dataSource = self
        //设置表格背景色
        self.tableView!.backgroundColor = UIColor(red: 0xf0/255, green: 0xf0/255,
                                                  blue: 0xf0/255, alpha: 1)
        //去除单元格分隔线
        self.tableView!.separatorStyle = .none
        
        //创建一个重用的单元格
        self.tableView!.register(UINib(nibName:"HomeTableViewCell", bundle:nil),
                                 forCellReuseIdentifier:"myCell")
        
        self.view.addSubview(self.tableView!)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    /*创建自定义导航*/
    func setupNavBar() {
        let backgroundView = UIView()
        backgroundView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        backgroundView.backgroundColor = UIColor(red: 0xf0/255, green: 0xf0/255,
                                                 blue: 0xf0/255, alpha: 1)
        self.view.addSubview(backgroundView)
        let leftButton = UIButton(type: UIButtonType.custom)
        leftButton.frame = CGRect(x: 0, y: 20, width: 60, height: 44);
        leftButton.setImage(UIImage(named: "back_button"), for: UIControlState())
        leftButton.addTarget(self, action: #selector(leftButtonClick), for: .touchUpInside)
        backgroundView.addSubview(leftButton)
        
        let titleLabel = UILabel()
        titleLabel.center = CGPoint(x: self.view.center.x, y: 45)
        titleLabel.bounds = CGRect(x: 0, y: 4, width: 200, height: 44)
        titleLabel.font = UIFont.systemFont(ofSize: 20)
        titleLabel.textColor = UIColor.blue
        titleLabel.text = "Simplevents";
        titleLabel.textAlignment = NSTextAlignment.center
        let labels = UILabel(frame: CGRect(x:50,y:30,width:50,height:44))
        labels.text = "今天"
        labels.font = UIFont.systemFont(ofSize: 14)
        let images = UIImageView(frame: CGRect(x:0,y:30,width:50,height:44))
        images.image = UIImage(named: "111")
        let imagess = UIImageView(frame: CGRect(x:80,y:45,width:20,height:14))
        imagess.image = UIImage(named: "113")
        let images1 = UIImageView(frame: CGRect(x:293,y:37,width:32,height:32))
        images1.image = UIImage(named: "48")
        let images2 = UIImageView(frame: CGRect(x:333,y:41,width:30,height:26))
        images2.image = UIImage(named: "112")
        backgroundView.addSubview(imagess)
        backgroundView.addSubview(images)
         backgroundView.addSubview(images1)
         backgroundView.addSubview(images2)
        backgroundView.addSubview(labels)
        backgroundView.addSubview(titleLabel)
        
        
    }
    @IBAction func leftButtonClick(){
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableData.count
    }
    
    //单元格高度
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath)
        -> CGFloat {
            return 200
    }
    
    //创建各单元显示内容(创建参数indexPath指定的单元）
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)
        -> UITableViewCell
    {
        //?
        let cell:HomeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! HomeTableViewCell
        
        
        
        
        //let cell:HomeTableViewCell = UITableViewCell(style: .default, reuseIdentifier:"mycel") as! HomeTableViewCell
            //as! HomeTableViewCell
        //let cell = UITableViewCell(style: .default, reuseIdentifier:identify)
        let item = tableData[indexPath.row]
        //cell.customLabel.text = item["title"]
        cell.images.image = UIImage(named:item["image"]!)
        
        
       
        
        //？
        let label =  UILabel(frame: CGRect.zero)
       label.translatesAutoresizingMaskIntoConstraints = false
       //label.text = "计算机技术快看看上课"
        
        let textview=UITextView(frame: CGRect.zero)
        textview.translatesAutoresizingMaskIntoConstraints = false
        textview.textColor = UIColor.gray
        //演示效果，暂时写死
        //textview.text = "UIDatePicker是一个控制器类,封装了UIPickerView,但是他是UIControl的子类"
        
        //let identify:String = "SwiftCell"
        //let cell = UITableViewCell(style: .default, reuseIdentifier:identify)
        //自动遮罩不可见区域,超出的不显示
       // cell.layer.masksToBounds = true
        //cell.contentView.addSubview(label)
        //cell.contentView.addSubview(textview)
        
        
        //创建一个控件数组
//        let views = ["label":label, "textview":textview]
//        cell.contentView.addConstraints(NSLayoutConstraint.constraints(
//            withVisualFormat: "H:|-15-[label]-15-|", options: [], metrics: nil,
//            views: views))
//        cell.contentView.addConstraints(NSLayoutConstraint.constraints(
//            withVisualFormat: "H:|-15-[textview]-15-|", options: [], metrics: nil,
//            views: views))
//        cell.contentView.addConstraints(NSLayoutConstraint.constraints(
//            withVisualFormat: "V:|[label(40)]", options: [], metrics: nil,
//            views: views))
//        cell.contentView.addConstraints(NSLayoutConstraint.constraints(
//            withVisualFormat: "V:|-40-[textview(80)]", options: [], metrics: nil,
//            views: views))
        //?
        return cell
    }
    //
    //头部滑动事件按钮（右滑按钮）
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt
        indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        //创建“更多”事件按钮
        let unread = UIContextualAction(style: .normal, title: nil) {
            (action, view, completionHandler) in
           // UIAlertController.showAlert(message: "点击了“未读”按钮")
            completionHandler(true)
        }
        //unread.backgroundColor = UIColor(red: 52/255, green: 120/255, blue: 246/255,
                                       //  alpha: 1)
        unread.backgroundColor = UIColor(red: 0, green: 255, blue: 255, alpha:10)
        unread.image = UIImage(named: "48")
        //返回所有的事件按钮
        let configuration = UISwipeActionsConfiguration(actions: [unread])
        return configuration
    }
    
    //
   // 删除
    /*func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String?{
        return "删除"
    }
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        
        if editingStyle == UITableViewCellEditingStyle.delete {
            
            self.tableData.remove(at: indexPath.row)
            //刷新tableview
            tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
        }
    }*/
    //尾部滑动事件按钮（左滑按钮）
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt
        indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        
        //创建“删除”事件按钮
        let delete = UIContextualAction(style: .destructive,title:nil) {
            (action, view, completionHandler) in
            //将对应条目的数据删除
            
            
            //self.tableData.remove(at: indexPath.row)
            completionHandler(true)
        }
        delete.backgroundColor = UIColor(red: 255, green: 00,
                                         blue: 00, alpha: 1)
        delete.image = UIImage(named: "32")
        //返回所有的事件按钮
        let configuration = UISwipeActionsConfiguration(actions: [delete])
        return configuration
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.tableView!.deselectRow(at: indexPath, animated: false)
        if let index = selectedCellIndexPaths.index(of: indexPath) {
            selectedCellIndexPaths.remove(at: index)
        }else{
            selectedCellIndexPaths.append(indexPath)
            jgk()
            
        }
        //强制改变高度
        //tableView.reloadRows(at: [indexPath], with: .automatic)
    }
    
    func jgk(){
        let alertController = UIAlertController(title: "信息详情", message: "2018-9-9:社团联合会", preferredStyle:.alert)
        
        // 设置2个UIAlertAction
        //let cancelAction = UIAlertAction(title: "取消", style:.cancel, handler: nil)
        let okAction = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            print("点击了好的")
        }
        
        // 添加
        //alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        
        // 弹出
        self.present(alertController, animated: true, completion: nil)
    }
    /*//点击单元格会引起cell高度的变化，所以要重新设置
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath)
        -> CGFloat {
            if selectedCellIndexPaths.contains(indexPath) {
                return 200

            }
            return 120
    }*/
    
}
